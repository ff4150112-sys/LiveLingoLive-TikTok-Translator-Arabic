package com.livelingo.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestAudio = 41
    private val languages = listOf(
        "التركية" to "tr-TR",
        "الأردية" to "ur-PK",
        "الإنجليزية" to "en-US"
    )
    private lateinit var languageSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            setBackgroundColor(0xFF101827.toInt())
        }
        fun text(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt()): TextView =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                setPadding(0, 12, 0, 14)
            }

        root.addView(text("LiveLingo", 30f))
        root.addView(text("مترجم البثوث المباشرة", 20f, 0xFFB8C9DD.toInt()))
        root.addView(text(
            "اختر لغة المتحدث. سيستمع التطبيق عبر ميكروفون الهاتف، ويتعرف على الكلام ثم يترجمه إلى العربية ويقرأه.",
            15f, 0xFFE0E8F2.toInt()
        ))

        languageSpinner = Spinner(this)
        languageSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            languages.map { it.first }
        )
        root.addView(languageSpinner, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        root.addView(Button(this).apply {
            text = "1) السماح بالنافذة العائمة"
            setOnClickListener { requestOverlayPermission() }
        })
        root.addView(Button(this).apply {
            text = "2) تشغيل المترجم"
            setOnClickListener { startTranslator() }
        })
        root.addView(Button(this).apply {
            text = "إيقاف المترجم"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        root.addView(text(
            "ملاحظة: هذه نسخة تجريبية. قد لا يلتقط Android صوت TikTok الداخلي؛ عندها ضع الهاتف قرب السماعة وارفع صوت البث. يتطلب التعرف على الكلام خدمة صوتية متاحة على الجهاز.",
            13f, 0xFFFFD58A.toInt()
        ))
        setContentView(root)
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            ))
        } else {
            Toast.makeText(this, "إذن النافذة العائمة مفعّل", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startTranslator() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        val lang = languages[languageSpinner.selectedItemPosition].second
        val intent = Intent(this, OverlayService::class.java).putExtra("source_language", lang)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
        Toast.makeText(this, "جارٍ تشغيل المترجم التجريبي", Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestAudio && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startTranslator()
        } else if (requestCode == requestAudio) {
            Toast.makeText(this, "يلزم إذن الميكروفون للتعرف على الكلام", Toast.LENGTH_LONG).show()
        }
    }
}
