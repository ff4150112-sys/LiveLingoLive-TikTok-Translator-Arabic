package com.livelingo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

class OverlayService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    private var windowManager: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var sourceText: TextView? = null
    private var translatedText: TextView? = null
    private var statusText: TextView? = null
    private var recognizer: SpeechRecognizer? = null
    private var translator: Translator? = null
    private var tts: TextToSpeech? = null
    private var sourceLocale = "tr-TR"
    private var isListening = false
    private var ttsReady = false

    override fun onCreate() {
        super.onCreate()
        createNotification()
        tts = TextToSpeech(this, this)
        showOverlay()
        prepareTranslator()
        startRecognition()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        sourceLocale = intent?.getStringExtra("source_language") ?: sourceLocale
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val channelId = "livelingo_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "LiveLingo", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setContentTitle("LiveLingo يعمل")
                .setContentText("استماع وترجمة تجريبية")
                .setSmallIcon(android.R.drawable.ic_dialog_info).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("LiveLingo يعمل")
                .setContentText("استماع وترجمة تجريبية")
                .setSmallIcon(android.R.drawable.ic_dialog_info).build()
        }
        startForeground(7, notification)
    }

    private fun showOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 18)
            setBackgroundColor(0xF2172B46.toInt())
        }
        panel.addView(TextView(this).apply {
            text = "LiveLingo • مباشر"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
        })
        statusText = TextView(this).apply {
            text = "جارٍ تجهيز الترجمة..."
            textSize = 12f
            setTextColor(0xFF9CCBFF.toInt())
            setPadding(0, 8, 0, 8)
        }
        panel.addView(statusText)
        sourceText = TextView(this).apply {
            text = "الكلام الأصلي سيظهر هنا"
            textSize = 13f
            setTextColor(0xFFD5E1EF.toInt())
            setPadding(0, 4, 0, 8)
        }
        panel.addView(sourceText)
        translatedText = TextView(this).apply {
            text = "الترجمة العربية ستظهر هنا"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 4, 0, 8)
        }
        panel.addView(translatedText)
        panel.addView(Button(this).apply {
            text = "إيقاف"
            setOnClickListener { stopSelf() }
        })

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 180
            width = (resources.displayMetrics.widthPixels * 0.78f).toInt()
        }
        overlay = panel
        windowManager?.addView(panel, params)
    }

    private fun prepareTranslator() {
        val source = when {
            sourceLocale.startsWith("tr") -> TranslateLanguage.TURKISH
            sourceLocale.startsWith("ur") -> TranslateLanguage.URDU
            else -> TranslateLanguage.ENGLISH
        }
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(source)
            .setTargetLanguage(TranslateLanguage.ARABIC)
            .build()
        translator = Translation.getClient(options)
        statusText?.text = "جارٍ تنزيل نموذج الترجمة عند الحاجة..."
        translator?.downloadModelIfNeeded()
            ?.addOnSuccessListener { statusText?.text = "جاهز • استمع للكلام" }
            ?.addOnFailureListener {
                statusText?.text = "تعذر تنزيل نموذج اللغة. تحقق من الإنترنت."
            }
    }

    private fun startRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText?.text = "خدمة التعرف على الكلام غير متاحة على هذا الجهاز"
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(this)
        }
        listenAgain()
    }

    private fun listenAgain() {
        if (isListening || recognizer == null) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, sourceLocale)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            isListening = true
            recognizer?.startListening(intent)
            statusText?.text = "أستمع الآن • $sourceLocale"
        } catch (_: Exception) {
            isListening = false
            statusText?.text = "تعذر بدء الاستماع"
        }
    }

    private fun translate(text: String) {
        if (text.isBlank()) return
        sourceText?.text = text
        translator?.translate(text)
            ?.addOnSuccessListener { arabic ->
                translatedText?.text = arabic
                if (ttsReady) tts?.speak(arabic, TextToSpeech.QUEUE_FLUSH, null, "livelingo_translation")
            }
            ?.addOnFailureListener {
                statusText?.text = "فشلت الترجمة؛ تحقق من تنزيل نموذج اللغة"
            }
    }

    override fun onReadyForSpeech(params: Bundle?) { statusText?.text = "أستمع..." }
    override fun onBeginningOfSpeech() { statusText?.text = "تم التقاط الكلام" }
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { isListening = false }
    override fun onError(error: Int) {
        isListening = false
        statusText?.text = "بانتظار الكلام..."
        windowManager?.let { overlay?.postDelayed({ listenAgain() }, 700) }
    }
    override fun onResults(results: Bundle?) {
        isListening = false
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        matches?.firstOrNull()?.let { translate(it) }
        listenAgain()
    }
    override fun onPartialResults(partialResults: Bundle?) {
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        matches?.firstOrNull()?.let { translate(it) }
    }
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("ar"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    override fun onDestroy() {
        isListening = false
        recognizer?.destroy()
        recognizer = null
        translator?.close()
        translator = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        overlay?.let { windowManager?.removeView(it) }
        overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
