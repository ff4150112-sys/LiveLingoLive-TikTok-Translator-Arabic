plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.livelingo.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.livelingo.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2"
    }
}
dependencies {
    implementation("com.google.mlkit:translate:17.0.3")
}
